
const express=require('express')
const app=express()

app.use(express.json())
app.use(express.static('public'))

let businesses=[
{name:'Rockys Bakery',location:'Soweto',industry:'Food',capital:500000,equity:20},
{name:'Kasi Logistics',location:'Alexandra',industry:'Transport',capital:300000,equity:15}
]

app.get('/api/businesses',(req,res)=>{
res.json(businesses)
})

app.post('/api/businesses',(req,res)=>{
businesses.push(req.body)
res.json({status:'ok'})
})

app.listen(3000,()=>console.log('Server running'))
