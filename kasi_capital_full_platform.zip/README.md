
KasiCapital Platform

Install Node.js

Run:

npm install
npm start

Open:

http://localhost:3000
