
fetch('/api/businesses')
.then(r=>r.json())
.then(data=>{

const list=document.getElementById('business-list')

data.forEach(b=>{

const div=document.createElement('div')
div.className='card'

div.innerHTML=`
<h3>${b.name}</h3>
<p>${b.location}</p>
<p>${b.industry}</p>
<p>Capital: R${b.capital}</p>
<p>Equity: ${b.equity}%</p>
`

list.appendChild(div)

})

})
