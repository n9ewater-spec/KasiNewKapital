
document.getElementById('form').addEventListener('submit',async(e)=>{

e.preventDefault()

const form=new FormData(e.target)
const data=Object.fromEntries(form.entries())

await fetch('/api/businesses',{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify(data)
})

alert('Application submitted')

})
